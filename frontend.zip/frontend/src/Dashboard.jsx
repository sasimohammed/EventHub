import { useEffect, useMemo, useState } from 'react';
import { api } from './api';

export default function Dashboard() {
  const [snapshot, setSnapshot] = useState(null);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('title');
  const [sortDirection, setSortDirection] = useState('asc');

  useEffect(() => {
    api
        .analyticsSummary()
        .then(setSnapshot)
        .catch((err) => setError(err.message));
  }, []);

  const events = snapshot?.eventsTable || [];

  const totalBookings = useMemo(
      () =>
          events.reduce(
              (sum, event) => sum + Number(event.bookingsCount || 0),
              0
          ),
      [events]
  );

  const totalRevenue = useMemo(
      () =>
          events.reduce(
              (sum, event) => sum + Number(event.revenue || 0),
              0
          ),
      [events]
  );

  const totalReviews = useMemo(
      () =>
          events.reduce(
              (sum, event) => sum + Number(event.reviewCount || 0),
              0
          ),
      [events]
  );

  const positiveReviews =
      snapshot?.sentimentTotals?.positive || 0;

  const filteredEvents = useMemo(() => {
    const result = events.filter((event) =>
        event.title
            .toLowerCase()
            .includes(search.toLowerCase())
    );

    result.sort((a, b) => {
      let first;
      let second;

      if (sortBy === 'title') {
        first = a.title.toLowerCase();
        second = b.title.toLowerCase();
      } else if (sortBy === 'bookings') {
        first = Number(a.bookingsCount || 0);
        second = Number(b.bookingsCount || 0);
      } else if (sortBy === 'reviews') {
        first = Number(a.reviewCount || 0);
        second = Number(b.reviewCount || 0);
      } else {
        first = Number(a.revenue || 0);
        second = Number(b.revenue || 0);
      }

      if (first < second) {
        return sortDirection === 'asc' ? -1 : 1;
      }

      if (first > second) {
        return sortDirection === 'asc' ? 1 : -1;
      }

      return 0;
    });

    return result;
  }, [events, search, sortBy, sortDirection]);

  const changeSort = (field) => {
    if (sortBy === field) {
      setSortDirection((current) =>
          current === 'asc' ? 'desc' : 'asc'
      );
    } else {
      setSortBy(field);
      setSortDirection('asc');
    }
  };

  if (error) {
    return (
        <main className="dashboard">
          <div className="dashboard-error">
            <div className="error-symbol">!</div>
            <h2>Dashboard unavailable</h2>
            <p>{error}</p>
          </div>
        </main>
    );
  }

  if (!snapshot) {
    return (
        <main className="dashboard">
          <div className="dashboard-loading">
            <div className="loading-circle"></div>
            <h2>Preparing your dashboard</h2>
            <p>Collecting the latest EventHub activity...</p>
          </div>
        </main>
    );
  }

  const sentiment = snapshot.sentimentTotals || {};

  return (
      <main className="dashboard">

        {/* HEADER */}
        <section className="dashboard-header">
          <div>
          <span className="dashboard-kicker">
            CONTROL CENTER
          </span>

            <h1>Activity overview</h1>

            <p>
              Monitor your events, bookings, revenue and
              audience feedback from one place.
            </p>
          </div>

          <div className="dashboard-date">
            <span>LAST UPDATED</span>
            <strong>
              {new Date(
                  snapshot.generatedAt
              ).toLocaleString()}
            </strong>
          </div>
        </section>

        {/* STAT CARDS */}
        <section className="dashboard-stats">

          <div className="dashboard-stat stat-blue">
            <div className="stat-top">
              <span>01</span>
              <span className="stat-symbol">↗</span>
            </div>

            <span className="stat-label">
            Total bookings
          </span>

            <strong>{totalBookings}</strong>

            <p>Confirmed reservations</p>
          </div>

          <div className="dashboard-stat stat-orange">
            <div className="stat-top">
              <span>02</span>
              <span className="stat-symbol">$</span>
            </div>

            <span className="stat-label">
            Revenue
          </span>

            <strong>
              ${totalRevenue.toFixed(0)}
            </strong>

            <p>Across all listed events</p>
          </div>

          <div className="dashboard-stat stat-green">
            <div className="stat-top">
              <span>03</span>
              <span className="stat-symbol">✦</span>
            </div>

            <span className="stat-label">
            Reviews
          </span>

            <strong>{totalReviews}</strong>

            <p>Total submitted feedback</p>
          </div>

          <div className="dashboard-stat stat-dark">
            <div className="stat-top">
              <span>04</span>
              <span className="stat-symbol">★</span>
            </div>

            <span className="stat-label">
            Positive feedback
          </span>

            <strong>{positiveReviews}</strong>

            <p>Positive sentiment detected</p>
          </div>

        </section>

        {/* MAIN DASHBOARD GRID */}
        <section className="dashboard-main-grid">

          {/* EVENT SUMMARY */}
          <div className="dashboard-card overview-card">

            <div className="dashboard-card-header">
              <div>
              <span className="card-kicker">
                PERFORMANCE
              </span>

                <h2>Event activity</h2>
              </div>

              <span className="card-count">
              {events.length} events
            </span>
            </div>

            <div className="activity-list">

              {events.length === 0 ? (
                  <div className="dashboard-empty">
                    No event data available.
                  </div>
              ) : (
                  events.map((event, index) => {
                    const bookings =
                        Number(event.bookingsCount || 0);

                    const percentage =
                        totalBookings > 0
                            ? Math.round(
                                (bookings / totalBookings) * 100
                            )
                            : 0;

                    return (
                        <div
                            className="activity-item"
                            key={event.eventId}
                        >

                          <div className="activity-number">
                            {String(index + 1).padStart(2, '0')}
                          </div>

                          <div className="activity-info">
                            <h3>{event.title}</h3>

                            <div className="activity-bar">
                        <span
                            style={{
                              width: `${percentage}%`,
                            }}
                        />
                            </div>
                          </div>

                          <div className="activity-value">
                            <strong>{bookings}</strong>
                            <span>bookings</span>
                          </div>

                        </div>
                    );
                  })
              )}

            </div>
          </div>

          {/* SENTIMENT */}
          <div className="dashboard-card sentiment-card">

            <div className="dashboard-card-header">
              <div>
              <span className="card-kicker">
                AUDIENCE
              </span>

                <h2>Feedback mood</h2>
              </div>
            </div>

            <div className="sentiment-total">
              <strong>{totalReviews}</strong>
              <span>total reviews</span>
            </div>

            <div className="sentiment-bars">

              <div className="sentiment-item">
                <div className="sentiment-label">
                <span>
                  <i className="mood-dot positive"></i>
                  Positive
                </span>

                  <strong>
                    {sentiment.positive || 0}
                  </strong>
                </div>

                <div className="mood-bar">
                <span
                    className="positive"
                    style={{
                      width: `${
                          totalReviews
                              ? ((sentiment.positive || 0) /
                                  totalReviews) *
                              100
                              : 0
                      }%`,
                    }}
                />
                </div>
              </div>

              <div className="sentiment-item">
                <div className="sentiment-label">
                <span>
                  <i className="mood-dot neutral"></i>
                  Neutral
                </span>

                  <strong>
                    {sentiment.neutral || 0}
                  </strong>
                </div>

                <div className="mood-bar">
                <span
                    className="neutral"
                    style={{
                      width: `${
                          totalReviews
                              ? ((sentiment.neutral || 0) /
                                  totalReviews) *
                              100
                              : 0
                      }%`,
                    }}
                />
                </div>
              </div>

              <div className="sentiment-item">
                <div className="sentiment-label">
                <span>
                  <i className="mood-dot negative"></i>
                  Negative
                </span>

                  <strong>
                    {sentiment.negative || 0}
                  </strong>
                </div>

                <div className="mood-bar">
                <span
                    className="negative"
                    style={{
                      width: `${
                          totalReviews
                              ? ((sentiment.negative || 0) /
                                  totalReviews) *
                              100
                              : 0
                      }%`,
                    }}
                />
                </div>
              </div>

            </div>

          </div>

        </section>

        {/* DETAILED STATISTICS */}
        <section className="dashboard-card detailed-card">

          <div className="detailed-header">

            <div>
            <span className="card-kicker">
              DATA TABLE
            </span>

              <h2>Detailed event statistics</h2>

              <p>
                Search and compare the performance of
                every event.
              </p>
            </div>

            <div className="table-search">
              <span>⌕</span>

              <input
                  type="text"
                  placeholder="Search events..."
                  value={search}
                  onChange={(e) =>
                      setSearch(e.target.value)
                  }
              />
            </div>

          </div>

          <div className="table-wrapper">

            <table className="dashboard-table">

              <thead>
              <tr>

                <th
                    onClick={() => changeSort('title')}
                >
                  Event
                  <SortArrow
                      active={sortBy === 'title'}
                      direction={sortDirection}
                  />
                </th>

                <th
                    onClick={() => changeSort('bookings')}
                >
                  Bookings
                  <SortArrow
                      active={sortBy === 'bookings'}
                      direction={sortDirection}
                  />
                </th>

                <th
                    onClick={() => changeSort('reviews')}
                >
                  Reviews
                  <SortArrow
                      active={sortBy === 'reviews'}
                      direction={sortDirection}
                  />
                </th>

                <th
                    onClick={() => changeSort('revenue')}
                >
                  Revenue
                  <SortArrow
                      active={sortBy === 'revenue'}
                      direction={sortDirection}
                  />
                </th>

                <th>
                  Status
                </th>

              </tr>
              </thead>

              <tbody>

              {filteredEvents.length === 0 ? (
                  <tr>
                    <td
                        colSpan="5"
                        className="table-empty"
                    >
                      No events match your search.
                    </td>
                  </tr>
              ) : (
                  filteredEvents.map((event) => {

                    const bookings =
                        Number(
                            event.bookingsCount || 0
                        );

                    return (
                        <tr key={event.eventId}>

                          <td>
                            <div className="table-event">

                          <span className="event-badge">
                            {event.title
                                .charAt(0)
                                .toUpperCase()}
                          </span>

                              <div>
                                <strong>
                                  {event.title}
                                </strong>

                                <small>
                                  ID #{event.eventId}
                                </small>
                              </div>

                            </div>
                          </td>

                          <td>
                            <strong>
                              {bookings}
                            </strong>
                          </td>

                          <td>
                            {Number(
                                event.reviewCount || 0
                            )}
                          </td>

                          <td>
                            <strong>
                              $
                              {Number(
                                  event.revenue || 0
                              ).toFixed(0)}
                            </strong>
                          </td>

                          <td>
                        <span
                            className={
                              bookings > 0
                                  ? 'table-status active'
                                  : 'table-status'
                            }
                        >
                          {bookings > 0
                              ? 'Active'
                              : 'No bookings'}
                        </span>
                          </td>

                        </tr>
                    );
                  })
              )}

              </tbody>

            </table>

          </div>

        </section>

      </main>
  );
}

function SortArrow({
                     active,
                     direction,
                   }) {
  if (!active) {
    return (
        <span className="sort-arrow">
        ↕
      </span>
    );
  }

  return (
      <span className="sort-arrow active">
      {direction === 'asc' ? '↑' : '↓'}
    </span>
  );
}